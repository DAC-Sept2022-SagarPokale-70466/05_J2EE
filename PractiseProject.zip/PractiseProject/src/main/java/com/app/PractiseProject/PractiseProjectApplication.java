package com.app.PractiseProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PractiseProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PractiseProjectApplication.class, args);
	}

}
