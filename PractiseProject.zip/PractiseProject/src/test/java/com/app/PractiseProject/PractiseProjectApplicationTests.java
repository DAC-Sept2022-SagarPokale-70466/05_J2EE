package com.app.PractiseProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PractiseProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
