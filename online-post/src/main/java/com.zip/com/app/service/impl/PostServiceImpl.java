/**
*	@Developer : Sagar_Pokale
*	@Date		 	   : 29-Dec-2022 9:50:47 AM
*/

package com.app.service.impl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.app.entity.Category;
import com.app.entity.Post;
import com.app.entity.User;
import com.app.excetions.ResourceNotFoundException;
import com.app.payloads.PostDTO;
import com.app.payloads.PostResponce;
import com.app.repository.CategoryRepo;
import com.app.repository.PostRepo;
import com.app.repository.UserRepo;
import com.app.service.PostService;

@Service
public class PostServiceImpl implements PostService {

	@Autowired
	private PostRepo postRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private CategoryRepo categoryRepo;

	public PostDTO createPost(PostDTO postDto, Integer userId, Integer categoryId) {

		User user = this.userRepo.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User", "UserId", userId));

		Category category = this.categoryRepo.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Catergory", "CategoryId", categoryId));

		Post post = this.modelMapper.map(postDto, Post.class);
		post.setImagename("default.png");
		post.setDate(new Date());
		post.setCategory(category);
		post.setUser(user);

		Post newSave = this.postRepo.save(post);

		return this.modelMapper.map(newSave, PostDTO.class);
	}

	@Override
	public PostDTO updatePost(PostDTO postDto, Integer postId) {

		Post post = this.postRepo.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post", "PostID", postId));
		post.setTitle(postDto.getTitle());
		post.setContent(postDto.getContent());
		post.setImagename(postDto.getImageName());
		Post save = this.postRepo.save(post);
		return this.modelMapper.map(save, PostDTO.class);
	}

	@Override
	public void deletePost(Integer postId) {

		Post post = this.postRepo.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post", "PostID", postId));
		this.postRepo.delete(post);
	}

	public PostResponce getAllPost(Integer pageNumber, Integer pageSize, String sortBy) {
		
//		int pageSize = 3;
//		int pageNo = 1;
		
		Pageable p = PageRequest.of(pageNumber, pageSize,Sort.by(sortBy).descending());
		
		Page<Post> pagePost = this.postRepo.findAll(p);		// 	returns page having post 
		
		List<Post> allContent = pagePost.getContent();		// list of post

		List<PostDTO> collect = allContent.stream().map((post) -> this.modelMapper.map(post, PostDTO.class))
				.collect(Collectors.toList());
		
		PostResponce postResponce = new PostResponce();
		postResponce.setContent(collect);
		postResponce.setPageNumber(pagePost.getNumber());
		postResponce.setPageSize(pagePost.getSize());
		postResponce.setTotalElements(pagePost.getTotalElements());
		postResponce.setTotalPages(pagePost.getTotalPages());
		postResponce.setLastPage(pagePost.isLast());
		return postResponce ;
	}

	@Override
	public PostDTO getPostById(Integer postId) {
		Post post = this.postRepo.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post", "PostId", postId));
		return this.modelMapper.map(post, PostDTO.class);
	}

	@Override
	public List<PostDTO> getPostsByCategory(Integer categoryId) {

		Category cat = this.categoryRepo.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Category", "CatergoryId", categoryId));
		List<Post> posts = this.postRepo.findByCategory(cat);
		List<PostDTO> postDto = posts.stream().map((post) -> this.modelMapper.map(post, PostDTO.class))
				.collect(Collectors.toList());
		return postDto;
	}

	@Override
	public List<PostDTO> getPostsByUser(Integer userId) {

		User user = this.userRepo.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User", "UserID", userId));
		List<Post> posts = this.postRepo.findByUser(user);
		List<PostDTO> postDto = posts.stream().map((post) -> this.modelMapper.map(post, PostDTO.class))
				.collect(Collectors.toList());
		return postDto;
	}

	@Override
	public List<PostDTO> searchPosts(String keyword) {
		List<Post> posts  = this.postRepo.seachByTitle("%"+keyword+"%");
		List<PostDTO> postDto  = posts.stream().map((post)->this.modelMapper.map(post, PostDTO.class)).collect(Collectors.toList());
		return postDto;
	}

}