/**
*	@Developer : Sagar_Pokale
*	@Date		 	   : 05-Jan-2023 6:31:56 PM
*/

package com.app.excetions;
public class ApiException extends RuntimeException {

	public ApiException(String message) {
		super(message);
	}

	public ApiException() {
		super();
	}
	
	
	
}
