/**
*	@Developer : Sagar_Pokale
*	@Date		 	   : 05-Jan-2023 9:49:10 PM
*/

package com.app.payloads;

import lombok.Data;

@Data
public class RoleDTO {
	
	private int Id;
	private String name;
	
	
}
