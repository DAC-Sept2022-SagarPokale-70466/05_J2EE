/**
*	@Developer : Sagar_Pokale
*	@Date		 	   : 01-Jan-2023 1:30:04 PM
*/

package com.app.payloads;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//default constructor is automatically createed
public class CommentDTO {

	private int id;

	private String content;

}
